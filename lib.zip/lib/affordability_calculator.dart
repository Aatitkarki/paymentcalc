import 'package:flutter/material.dart';

class AffordabilityCalculator extends StatefulWidget {
  @override
  _AffordabilityCalculatorState createState() =>
      _AffordabilityCalculatorState();
}

class _AffordabilityCalculatorState extends State<AffordabilityCalculator> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
