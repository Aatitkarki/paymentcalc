import 'dart:ui';

import 'package:flutter/cupertino.dart';

class Data {
  final String name;
  double value;
  final Color color;
  Data({@required this.name, @required this.value, @required this.color});
}
